/*
Copyright (C) 2016 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:
Part of CoreAudio Utility Classes
*/

#ifndef __MatrixMixerVolumes_h__
#define __MatrixMixerVolumes_h__

#if !defined(__COREAUDIO_USE_FLAT_INCLUDES__)
	#include <AudioUnit/AudioUnit.h>
#else
	#include <AudioUnit.h>
#endif

#if defined(__cplusplus)
extern "C"
{
#endif

// prints the matrix mixer volumes of a specific audio unit to the given file
void	 PrintMatrixMixerVolumes (FILE* file, AudioUnit au);				

// prints the mixer volumes for the specific scope of the audio unit
// results will be printed to the speficied file "file" with identifiying string tag "str"		
OSStatus PrintBuses (FILE* file, const char* str, AudioUnit au, AudioUnitScope inScope);
#if defined(__cplusplus)
}
#endif

#endif
