### SonogramViewDemo ###

===========================================================================
DESCRIPTION:

The SonogramViewDemo project builds an audio unit with a view that displays a sonogram of the input audio. It provides sample code for creating custom Cocoa views, as well as use of the CoreAudio spectral processor code.

===========================================================================
BUILD REQUIREMENTS:

Mac OS X Lion v10.7 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X Lion v10.7 or later

===========================================================================
PACKAGING LIST:

SonogramViewDemo.h
SonogramViewDemo.cpp
- Main code for the audio unit processing and manipulation

CASonogramView.hCASonogramView.mm
- View class for processing sonogram display

SonogramViewDemoView.hSonogramViewDemoView.mm
- Class for the Cocoa view

SonogramViewDemoViewFactory.hSonogramViewDemoViewFactory.mm
- Class for the view factory

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0.1
- First version.

===========================================================================
Copyright (C) 2011 Apple Inc. All rights reserved.
