/*
	File:		BaseWindow.cp

	Contains:	Base class for a window.

	Version:	Mac OS X

	Disclaimer:	IMPORTANT:  This Apple software is supplied to you by Apple Computer, Inc.
				("Apple") in consideration of your agreement to the following terms, and your
				use, installation, modification or redistribution of this Apple software
				constitutes acceptance of these terms.  If you do not agree with these terms,
				please do not use, install, modify or redistribute this Apple software.

				In consideration of your agreement to abide by the following terms, and subject
				to these terms, Apple grants you a personal, non-exclusive license, under Apple�s
				copyrights in this original Apple software (the "Apple Software"), to use,
				reproduce, modify and redistribute the Apple Software, with or without
				modifications, in source and/or binary forms; provided that if you redistribute
				the Apple Software in its entirety and without modifications, you must retain
				this notice and the following text and disclaimers in all such redistributions of
				the Apple Software.  Neither the name, trademarks, service marks or logos of
				Apple Computer, Inc. may be used to endorse or promote products derived from the
				Apple Software without specific prior written permission from Apple.  Except as
				expressly stated in this notice, no other rights or licenses, express or implied,
				are granted by Apple herein, including but not limited to any patent rights that
				may be infringed by your derivative works or by other works in which the Apple
				Software may be incorporated.

				The Apple Software is provided by Apple on an "AS IS" basis.  APPLE MAKES NO
				WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
				WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
				PURPOSE, REGARDING THE APPLE SOFTWARE OR ITS USE AND OPERATION ALONE OR IN
				COMBINATION WITH YOUR PRODUCTS.

				IN NO EVENT SHALL APPLE BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
				CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
				GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
				ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION, MODIFICATION AND/OR DISTRIBUTION
				OF THE APPLE SOFTWARE, HOWEVER CAUSED AND WHETHER UNDER THEORY OF CONTRACT, TORT
				(INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN IF APPLE HAS BEEN
				ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

	Copyright � 1997-2001 Apple Computer, Inc., All Rights Reserved
*/

#include "AppearanceSamplePrefix.h"

#if !BUILDING_FOR_CARBON_8
	#include <Carbon/Carbon.h>
#else
	#include <Carbon.h>
#endif

#include "BaseWindow.h"

BaseWindow::BaseWindow( WindowClass inClass, WindowAttributes inAttributes, const Rect& bounds ) :
		TWindow( inClass, inAttributes, bounds )
{
}

BaseWindow::BaseWindow( WindowRef window ) : TWindow( window )
{
}

BaseWindow::BaseWindow( SInt16 resID ) : TWindow( GetNewCWindow( resID, NULL, (WindowRef)-1L ) )
{
}

void BaseWindow::DoDragClick(EventRecord *event)
{
    BitMap		bitMap;
    DragWindow( GetWindowRef(), event->where, &GetQDGlobalsScreenBits( &bitMap )->bounds );
}

BaseWindow::~BaseWindow()
{
	MenuHandle theMenu;
	
	theMenu = GetMyMenu();
	
	if (theMenu)
	{
 		DeleteMenu( GetMenuID( theMenu ) );
 		DrawMenuBar();
	}
}

void
BaseWindow::AdjustMenus()
{
}

void
BaseWindow::HandleMenuSelection( SInt16 menuID, SInt16 itemNo )
{
	#pragma unused( menuID, itemNo )
}

void
BaseWindow::HandleKeyDown( EventRecord& )
{
}

void
BaseWindow::Resize( SInt16 width, SInt16 height )
{
	SizeWindow( GetWindowRef(), width, height, true );
}

void
BaseWindow::HandleClick( EventRecord& event )
{
#pragma unused( event )
}

MenuHandle BaseWindow::GetMyMenu(void)
{
	return(nil);  // if someone hasn't overridden this, they don't have a menu to get!
}

