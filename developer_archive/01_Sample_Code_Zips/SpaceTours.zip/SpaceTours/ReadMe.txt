This is an example iAd that uses the iAd JS framework. It is
a mini application that is selling tours in space. The application
has a main menu which allows the user to select between seeing
photos, prices and videos. There is also a map to show the user
the location of the nearest physical stores (for the fake company).
Lastly, the company are selling some items from the iTunes store.

The video and image assets in this example come
from NASA's public domain archive.

http://nasa.gov/
