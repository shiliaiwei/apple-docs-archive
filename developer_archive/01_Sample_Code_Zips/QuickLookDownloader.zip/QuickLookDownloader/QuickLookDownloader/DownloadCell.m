/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 DownloadCell can display a title, an icon and a subtitle.
 */

#import "DownloadCell.h"

#define SUBTITLE_SIZE [NSFont smallSystemFontSize]

@implementation DownloadCell

- (id)copyWithZone:(NSZone *)zone
{
    DownloadCell *result = [super copyWithZone:zone];
    result.originalURL = [self.originalURL copy];
    return result;
}

- (void)drawWithFrame:(NSRect)cellFrame inView:(NSView *)controlView
{
    CGFloat textHeight = TEXT_SIZE;
    CGFloat subtitleHeight = SUBTITLE_SIZE;
    CGFloat totalHeight = textHeight + subtitleHeight + 6.0;
    
    CGFloat deltaY = (CGRectGetHeight(cellFrame) - totalHeight) / 2.0;
    
    cellFrame.size.height = totalHeight;
    cellFrame.origin.y += deltaY;

    cellFrame = NSIntegralRect(cellFrame);
    
    NSRect textFrame;
    NSRect subtextFrame;
    
    NSDivideRect(cellFrame, &textFrame, &subtextFrame, (TEXT_SIZE + 4.0), [controlView isFlipped] ? NSMinYEdge : NSMaxYEdge);
    
    [super drawWithFrame:textFrame inView:controlView];
    
    if (self.originalURL)
	{
        NSString *stringToDisplay = [self.originalURL absoluteString];
        static NSDictionary *attributes = nil;
        static NSDictionary *selectedAttributes = nil;
        
        if (!attributes)
		{
            attributes = @{NSForegroundColorAttributeName:[NSColor darkGrayColor],
                           NSFontAttributeName:[NSFont systemFontOfSize:SUBTITLE_SIZE]};
            selectedAttributes = @{NSForegroundColorAttributeName:[NSColor whiteColor],
                                   NSFontAttributeName:[NSFont systemFontOfSize:SUBTITLE_SIZE]};
        }
        
        [stringToDisplay drawInRect:subtextFrame withAttributes:([self backgroundStyle] == NSBackgroundStyleDark) ? selectedAttributes : attributes];
    }
}

@end
