/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 DownloadItem stores information of a downloaded item used by MyDocument.
*/

@import Cocoa;

@interface DownloadItem : NSObject <NSTableViewDelegate, NSTableViewDataSource>

- (id)initWithOriginalURL:(NSURL *)downloadURL fileURL:(NSURL *)onDiskURL;
- (id)initWithSavedPropertyList:(id)propertyList;

@property (readonly) NSURL *originalURL;
@property (readonly) NSURL *resolvedFileURL;

@property (weak, readonly) NSString *displayName;
@property (nonatomic, strong) NSImage *iconImage;

@property (unsafe_unretained, readonly) id propertyListForSaving;

@end
