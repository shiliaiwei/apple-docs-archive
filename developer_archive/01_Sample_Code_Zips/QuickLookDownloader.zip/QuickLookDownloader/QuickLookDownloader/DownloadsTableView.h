/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 DownloadsTableView overrides NSTableView to support space bar to open Quick Look panel.
*/

@import Cocoa;

@interface DownloadsTableView : NSTableView

@end
