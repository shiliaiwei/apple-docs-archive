/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Application delegate class ; opens/closes the Quick Look panel.
 */

@import Cocoa;
@import Quartz;  // for QLPreviewPanel

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)notification
{
    if ([[NSDocumentController sharedDocumentController] documents].count == 0)
    {
        // open a new document window if there are none open
        [[NSDocumentController sharedDocumentController] newDocument:self];
    }
}

- (IBAction)togglePreviewPanel:(id)previewPanel
{
    if ([QLPreviewPanel sharedPreviewPanelExists] && [[QLPreviewPanel sharedPreviewPanel] isVisible])
    {
        [[QLPreviewPanel sharedPreviewPanel] orderOut:nil];
    }
    else
    {
        [[QLPreviewPanel sharedPreviewPanel] makeKeyAndOrderFront:nil];
    }
}

- (BOOL)validateMenuItem:(NSMenuItem *)menuItem
{
    SEL action = [menuItem action];
    if (action == @selector(togglePreviewPanel:))
    {
        if ([QLPreviewPanel sharedPreviewPanelExists] && [[QLPreviewPanel sharedPreviewPanel] isVisible])
        {
            [menuItem setTitle:NSLocalizedString(@"Close Quick Look panel", "")];
        }
        else
        {
            [menuItem setTitle:NSLocalizedString(@"Open Quick Look panel", "")];
        }
        return YES;
    }
    return NO;
}

@end
