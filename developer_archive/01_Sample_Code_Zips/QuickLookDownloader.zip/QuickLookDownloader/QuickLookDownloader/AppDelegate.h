/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Application delegate class ; opens/closes the Quick Look panel.
*/

@import Cocoa;

@interface AppDelegate : NSObject <NSApplicationDelegate>

- (IBAction)togglePreviewPanel:(id)previewPanel;

@end
