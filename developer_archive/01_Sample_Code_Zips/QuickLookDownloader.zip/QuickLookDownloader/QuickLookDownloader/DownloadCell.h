/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 DownloadCell can display a title, an icon and a subtitle.
*/

@import Cocoa;

#define TEXT_SIZE 12.0

@interface DownloadCell : NSTextFieldCell

@property (copy) NSURL *originalURL;

@end
