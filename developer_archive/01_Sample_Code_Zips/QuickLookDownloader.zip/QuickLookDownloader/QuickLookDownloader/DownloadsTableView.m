/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 DownloadsTableView overrides NSTableView to support space bar to open Quick Look panel.
 */

#import "DownloadsTableView.h"
#import "AppDelegate.h"

@implementation DownloadsTableView

- (void)keyDown:(NSEvent *)theEvent
{
	NSString *key = [theEvent charactersIgnoringModifiers];
	if ([key isEqual:@" "])	// Space key opens the preview panel.
	{
		AppDelegate *appDelegate = [NSApp delegate];
		[appDelegate togglePreviewPanel:self];
	}
	else
	{
		[super keyDown:theEvent];
	}
}

@end
