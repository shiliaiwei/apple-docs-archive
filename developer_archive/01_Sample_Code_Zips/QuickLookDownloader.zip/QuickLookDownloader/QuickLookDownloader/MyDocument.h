/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 MyDocument manages a list of downloaded items.
*/

@import Cocoa;

@interface MyDocument : NSDocument

@end
