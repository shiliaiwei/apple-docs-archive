/*
Copyright (C) 2013-2015 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:
Application delegate
*/

#import "AppDelegate.h"
#import "CollectionViewController.h"

@implementation AppDelegate {
    CollectionViewController *_viewController;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    
    _viewController = [[CollectionViewController alloc] initWithNibName:@"CollectionViewController" bundle:nil];
    self.window.rootViewController = _viewController;
    [self.window makeKeyAndVisible];
    return YES;
}

@end
