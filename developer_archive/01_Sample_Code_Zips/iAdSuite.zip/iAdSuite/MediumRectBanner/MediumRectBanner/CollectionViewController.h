/*
 Copyright (C) 2013-2015 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 A simple view controller that manages a collection view controller and a medium rect ADBannerView
*/

#import <UIKit/UIKit.h>

@interface CollectionViewController : UICollectionViewController

@end
