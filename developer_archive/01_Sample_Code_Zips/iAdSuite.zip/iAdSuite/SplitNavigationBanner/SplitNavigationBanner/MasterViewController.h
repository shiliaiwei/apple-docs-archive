/*
Copyright (C) 2013-2015 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:
A simple view controller that manages a table view
*/

#import <UIKit/UIKit.h>

@class TextViewController;

@interface MasterViewController : UITableViewController

@property (nonatomic, strong) TextViewController *detailViewController;

@end
