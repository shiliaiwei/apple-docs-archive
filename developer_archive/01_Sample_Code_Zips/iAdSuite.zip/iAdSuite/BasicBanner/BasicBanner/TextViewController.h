/*
Copyright (C) 2013-2015 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:
A simple view controller that manages a content view and an ADBannerView
*/

#import <UIKit/UIKit.h>
#import <iAd/iAd.h>

@interface TextViewController : UIViewController <ADBannerViewDelegate>

@property (nonatomic, copy) NSString *text;

@end
