#version 150

in vec3 attribPosition;
in vec3 attribNormal;

uniform float scale;
uniform mat4 modelTransformMatrix;
uniform mat4 cameraMatrix;
uniform mat4 projectionMatrix;
uniform vec4 color;

flat out vec3 normal;
out vec4 eyePos;
out vec4 primaryColor;

void main() {
	mat4 scaleMatrix = mat4(scale);
	scaleMatrix[3].w = 1.0;
	mat4 transform = cameraMatrix * modelTransformMatrix * scaleMatrix;
	mat3 normalTransform = mat3(transform[0].xyz, transform[1].xyz, transform[2].xyz);
    // normal
	normal = normalize(transform * vec4(attribNormal, 0.0)).xyz;
    // position
	eyePos = transform * vec4(attribPosition, 1.0);
	gl_Position = projectionMatrix * eyePos;
    // color
	primaryColor = color;
}