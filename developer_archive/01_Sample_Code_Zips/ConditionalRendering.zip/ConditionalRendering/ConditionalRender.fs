#version 150

flat in vec3 normal;
in vec4 eyePos;
in vec4 primaryColor;

uniform vec3 lightPos;
uniform vec3 lightColor;

out vec4 fragColor;

void main()
{
	vec3 view = normalize(-eyePos.xyz);
	vec3 L = normalize(lightPos-eyePos.xyz);
	float attenuation = max(0.0, dot(L, normal));
	vec3 reflectvec = normalize(reflect(-L, normal));
	float spec = max(dot(reflectvec, view),0.0);
	fragColor = primaryColor + vec4(min(pow(spec, 32.0)+attenuation*lightColor, 1.0), 1);
}