
SimpleStocks
============

The SimpleStocks sample application demonstrates how to use UIKit classes and the Core Graphics framework to draw content for iOS. From this example you will learn about UIKit's UIBezierPath class. In the sample path objects are used to both draw content and clip content. In addition you will see examples of using patterns to fill paths as well as using a path to clip images.

Discussion
----------
This example shows how to use various drawing API's in UIKit.

- UIBezierPath for building simple and complex paths
- UIBezierPath for clipping
- Gradients
- How the drawing system works in UIKit
- Performance Optimizations for drawing


Packing List
------------
APLSimpleStockView
This is the graph view where the drawing is done.

APLSimpleStockViewController
This view controller acts as the data source for simple stock view.

APLDailyTradeInfo
The daily trade model.

APLDailyTradeInfoSource
The daily trade model data.

APLAppDelegate
Trivial application delegate.

===========================================================================
Copyright (C) 2011-13 Apple Inc. All rights reserved.
