/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The OpenGL ES view which renders a rotating cube. Responsible for creating a CADisplayLink for the new target display when a connection/disconnection occurs.
 */

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

#import "UserControlDelegate.h"

@interface GLView : UIView

@property (readonly, nonatomic, getter=isAnimating) BOOL animating;
@property (nonatomic) NSInteger animationFrameInterval;
@property (nonatomic, strong) id <UserControlDelegate> userControlDelegate;
@property (nonatomic, weak) UIScreen *targetScreen;

- (void)startAnimation;
- (void)stopAnimation;
- (void)drawView:(id)sender;

@end
