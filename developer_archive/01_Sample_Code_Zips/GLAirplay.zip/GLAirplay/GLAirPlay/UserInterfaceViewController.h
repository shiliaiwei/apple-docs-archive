/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 This UIViewController configures the appearances of the UI when an external display is connected/disconnected.
 */

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

#import "UserControlDelegate.h"

@interface UserInterfaceViewController : UIViewController <UserControlDelegate>

@property (nonatomic, weak) IBOutlet UISlider *slider;

- (void)screenDidConnect;
- (void)screenDidDisconnect;

@end
