/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The root view controller. Demonstrates detailed steps on how to show content on an external display.
 */

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController

@property (nonatomic, strong) UIViewController *userInterfaceController;
@property (nonatomic, strong) UIViewController *glController;

@end
