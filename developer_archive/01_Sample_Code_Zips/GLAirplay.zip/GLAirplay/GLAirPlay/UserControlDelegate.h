/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The object that conforms to this UserControlDelegate protocol is responsible for setting the GL cube's rotating radius.
 */

#import <Foundation/Foundation.h>

@protocol UserControlDelegate <NSObject>

-(float)rotatingRadius;

@end
