/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 An Obj-C class which wraps an OpenAL playback environment
 */

#import <UIKit/UIKit.h>
#import <OpenAL/al.h>
#import <OpenAL/alc.h>

@interface CubePlayback : NSObject

@property			BOOL isPlaying; // Whether the sound is playing or stopped
@property			BOOL wasInterrupted; // Whether playback was interrupted by the system
@property			float* sourcePos; // The coordinates of the sound source
@property			float* listenerPos; // The coordinates of the listener
@property			float listenerRotation; // The rotation angle of the listener in radians

- (void)initOpenAL;
- (void)teardownOpenAL;

- (void)startSound;
- (void)stopSound;

@end