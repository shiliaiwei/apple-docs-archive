=============================================================================

Read Me Notes to "JavaSplashScreen" Demo and Sample Code

=============================================================================
This sample code shows how to display a Cocoa splash screen while properly
instantiating the 1.4.1 JVM from a Cocoa application. Custom launchers and displaying native splash screens are not supported when using JDK 1.3.1.
=============================================================================
The minimum runtime requirements for this Sample Code are:

- Mac OS X 10.2 or later
- JDK 1.4.1
=============================================================================
For more examples of displaying splash screens in a Cocoa application please see the RoundTransparentWindow sample in the Cocoa sample code.