### CSS Effects: Lightbox ###

===========================================================================
DESCRIPTION:

This sample code shows you how to create a Lightbox photo viewer using CSS transition, transforms and animations.

===========================================================================
BUILD REQUIREMENTS:

None

===========================================================================
RUNTIME REQUIREMENTS:

Safari 4 or later, iPhoneOS 3.2 or later

===========================================================================
PACKAGING LIST:

ReadMe.txt
chasing-arrows.png
close_button.png
lightbox.css
lightbox.html
lightbox.js
list.txt
shared.css
utilities.js
images/large/DSCN1204.JPG
images/large/DSC_2040.JPG
images/large/DSC_2046.JPG
images/large/DSC_2069.JPG
images/large/DSC_2072.JPG
images/large/DSC_2083.JPG
images/large/DSC_2307.JPG
images/large/DSC_2308.JPG
images/thumb/DSCN1204.JPG
images/thumb/DSC_2040.JPG
images/thumb/DSC_2046.JPG
images/thumb/DSC_2069.JPG
images/thumb/DSC_2072.JPG
images/thumb/DSC_2083.JPG
images/thumb/DSC_2307.JPG
images/thumb/DSC_2308.JPG

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.1
  Updated images, minor code revisions.

Version 1.0
- First version.

===========================================================================
Copyright (C) 2010 Apple Inc. All rights reserved.
